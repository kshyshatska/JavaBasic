package model;

public enum Sex {
    MALE, FEMALE
}
