package org.example.model;

public enum Sex {
    MALE, FEMALE
}
